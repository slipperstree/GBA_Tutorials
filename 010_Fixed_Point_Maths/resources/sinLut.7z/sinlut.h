//
// Sine lut; 512 entries, 12 fixeds
//

#define sin_lutLen 1024

#define sin_lut_Size 512

extern const short sin_lut[512];