
//{{BLOCK(rocket4bpp)

//======================================================================
//
//	rocket4bpp, 32x64@4, 
//	+ palette 15 entries, not compressed
//	+ 32 tiles Metatiled by 4x8 not compressed
//	Total size: 30 + 1024 = 1054
//
//	Time-stamp: 2017-10-18, 23:04:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ROCKET4BPP_H
#define GRIT_ROCKET4BPP_H

#define rocket4bppTilesLen 1024
extern const unsigned short rocket4bppTiles[512];

#define rocket4bppPalLen 30
extern const unsigned short rocket4bppPal[16];

#endif // GRIT_ROCKET4BPP_H

//}}BLOCK(rocket4bpp)
